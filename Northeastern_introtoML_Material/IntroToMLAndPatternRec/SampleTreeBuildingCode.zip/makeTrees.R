myGainPlot <- function(myClassGroundTruth,myClassPredictedProb,myClassValue) {
  
  # Combine the actual and predicted values
  gain_data <- data.frame(
    actual = myClassGroundTruth,
    predicted = myClassPredictedProb
  )
  
  # Sort the data by predicted probabilities
  gain_data <- gain_data[order(-gain_data$predicted), ]
  
  # Compute the cumulative gain
  gain_data$cumulative_actual <- cumsum(gain_data$actual == myClassValue)
  gain_data$cumulative_total <- 1:nrow(gain_data)
  gain_data$cumulative_percentage <- gain_data$cumulative_actual / 
    sum(gain_data$actual == myClassValue)
  gain_data$cumulative_total_percentage <- gain_data$cumulative_total / nrow(gain_data)
  
  # Create a gain chart
  plt <- ggplot(gain_data, aes(x = cumulative_total_percentage, y = cumulative_percentage)) +
    geom_line() +
    geom_abline(slope = 1, intercept = 0, linetype = "dashed") +
    labs(
      title = paste("Gain Chart, carb class=", myClassValue, "vs rest"),
      x = "Cumulative Percentage of Total",
      y = "Cumulative Gain"
    )
  
  return(plt)
}
# create folds
foldIndex <- sample(1:F,nrow(mydf),replace=TRUE)

#hyperparameters arranged in rows, along with xval errors
myHyparWithCost <- data.frame(maxdepth=2:8)
myHyparWithCost$Perr <- rep(NA,nrow(myHyparWithCost))
myHyparWithCost$MSE <- rep(NA,nrow(myHyparWithCost))

#loop over hyperparameter(s)
for (hyparIdx in 1:nrow(myHyparWithCost)) {
    mymaxdepth <- myHyparWithCost$maxdepth[hyparIdx]
    
  # col 1:numClasses will be the xval posterior class probabilities
  # the last column will be ground truth
  myClassify <- matrix(0,nrow=length(foldIndex),ncol=numClasses+1)
  myClassify[,numClasses+1] <- mydf$carb
  
  # col 1 will be the estimated col2 is ground truth
  myRegress <- matrix(0,nrow=length(foldIndex),ncol=2)
  colnames(myRegress) <- c("estimated","truth")
  myRegress[,"truth"] <- as.numeric(mydf$mpg)
  
  # control parameters for both trees
  mycontrol <-  rpart.control(minsplit=5, cp = 0.01, 
                maxcompete = 4, maxsurrogate = 5, usesurrogate = 2, xval = 10,
                surrogatestyle = 0, maxdepth = mymaxdepth) 
  
  # parameters for decision tree
  myClassparms <- list(split="information")
  
  # loop over test fold
   for (testFold in 1:F) {
     
     #decision tree training
     myClassmodel <- rpart(carb ~ ., data=mydf, subset=foldIndex!=testFold,parms=myClassparms,
                      method="class", control=mycontrol)
     #decision tree validation
     myTestC <- predict(myClassmodel,mydf[foldIndex==testFold,])
     myClassify[foldIndex==testFold,1:numClasses] <- myTestC
     
     #regression tree training
     myRegressmodel <- rpart(mpg ~ ., data=mydf, subset=foldIndex!=testFold,
                      method="anova", control=mycontrol)
     #regression tree validation
     myTestR<- predict(myRegressmodel,mydf[foldIndex==testFold,],type="vector")
     myRegress[foldIndex==testFold,"estimated"] <- myTestR
   }
  #evaluate hyperparameter metrics
  decide <- max.col(myClassify[,1:numClasses])
  myHyparWithCost$Perr[hyparIdx] <- sum(myClassify[,numClasses+1]!=decide)/nrow(myClassify)
  myHyparWithCost$MSE[hyparIdx] <- mean(abs(myRegress[,"truth"]-myRegress[,"estimated"])^2)
}
# best hyperparameters for each tree
bestPerrIdx <- which.min(myHyparWithCost$Perr)
bestMSEIdx <- which.min(myHyparWithCost$MSE)

# best full-data classifier model
# best control parameters for decision tree
mycontrol <-  rpart.control(minsplit=5, cp = 0.01, 
              maxcompete = 4, maxsurrogate = 5, usesurrogate = 2, xval = 10,
              surrogatestyle = 0, maxdepth = myHyparWithCost$maxdepth[bestPerrIdx])
myClassmodel <- rpart(carb ~ ., data=mydf ,parms=myClassparms,
                  method="class", control=mycontrol)
rpart.plot(myClassmodel)
# decisions for all data, using full-data model (!)
myClassify[,1:numClasses] <- predict(myClassmodel,mydf)
decide <- max.col(myClassify[,1:numClasses])

# best full-data regression model
# best control parameters for regression tree
mycontrol <-  rpart.control(minsplit=5, cp = 0.01, 
              maxcompete = 4, maxsurrogate = 5, usesurrogate = 2, xval = 10,
              surrogatestyle = 0, maxdepth = myHyparWithCost$maxdepth[bestMSEIdx])
myRegressmodel <- rpart(mpg ~ ., data=mydf ,
                  method="anova", control=mycontrol)
rpart.plot(myRegressmodel)
# regression for all data, using full-data model (!)
myRegress[,"estimated"]<- predict(myRegressmodel,mydf,type="vector")

#confusion matrix
myconfusedMatrix <- confusionMatrix(data=as.factor(max.col(myClassify[,1:numClasses])),
                                    reference=as.factor(myClassify[,numClasses+1]))
print(myconfusedMatrix)

# classifier holdout accuracy
print(paste("classifier accuracy=", myconfusedMatrix$overall["Accuracy"]))

# classifier gains table and chart
mygains <- gains(actual=myRegress[,"truth"],predicted=myRegress[,"estimated"], groups=10)
print("gains table")
print(mygains)
plot(mygains, y=NULL, xlab="Depth of File", ylab="Mean Response",
     type="b", col=c("red3","bisque4","blue4"), pch=c(1,1,1), lty=c(1,1,1),
     legend=c(
       "Mean Response","Cumulative Mean Response","Mean Predicted Response"),
     ylim=c(min(c(mygains$mean.resp,mygains$mean.prediction)),
            max(c(mygains$mean.resp,mygains$mean.prediction))), main="Gains Table Plot")

for (carbClass in 1:length(levels(mydf$carb))) {
  plt <- myGainPlot(myClassify[,numClasses+1],myClassify[,carbClass],carbClass)
  plot(plt)
}


# xval absolute and RMS errors
AE <- abs(myRegress[,1]-myRegress[,2])
SE <- AE^2
print(paste("MAE=",mean(AE)))
print(paste("RMSE=",sqrt(mean(SE))))