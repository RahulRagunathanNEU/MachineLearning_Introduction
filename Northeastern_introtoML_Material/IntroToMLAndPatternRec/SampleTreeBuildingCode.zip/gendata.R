library(rpart)
library(ggplot2)
library(datasets)
library(rpart.plot)
library(caret)
library(gains)
library(pROC)

# load dataset
data(mtcars)
mydf <- mtcars[-c(30,31),] # gives error when in holdout fold

# target will be number of carbs.
mydf$carb <- as.factor(mydf$carb)

#number of folds
F <- 10

#number of classes
numClasses <- length(levels(mydf$carb))