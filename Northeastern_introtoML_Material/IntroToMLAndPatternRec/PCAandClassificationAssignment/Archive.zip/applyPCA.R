library(corrr)
library(ggcorrplot)
library(FactoMineR)
library(factoextra)
#load data
measurements <- read.table("trainingData.csv",header=TRUE)
# run PCA
# uncomment if scaling is desired
measurementsNormalized <- scale(measurements)
# no scaling done
#measurementsNormalized <- measurements
data.pca <- princomp(measurementsNormalized)
print(summary(data.pca))
plt <- fviz_eig(data.pca, addLabels = TRUE)
plot(plt)
plt <- fviz_pca_var(data.pca, axes=c(1,2), col.var = "cos2", gradient.cols = c("black", "orange", "green"), repel = TRUE )
plot(plt)

# plot first loading
plt <- ggplot() + geom_col(aes(x=1:ncol(measurements),y=data.pca$loadings[,1]))
print(plt)

# save high dimensional stuff
write.table(as.data.frame(measurements),"measurementPointHighD.csv" )

# 2D scatter plot
measLowD <- data.frame(firstScore=data.pca$scores[,1], secondScore=data.pca$scores[,2], class=ptCls)
plt <- ggplot(measLowD) + geom_point(aes(x=firstScore,y=secondScore, colour=class,alpha=0.2)) 
print(plt)

# 1D scatter plot
plt <- ggplot(measLowD) + geom_point(aes(x=firstScore,y=0, colour=class, alpha=0.2)) 
print(plt)

# histograms of first scores (both classes)
plt <- ggplot(measLowD, aes(x=firstScore, fill=class)) + geom_histogram(alpha=0.2,position="identity")
print(plt)
# histograms of second scores (both classes)
plt <- ggplot(measLowD, aes(x=secondScore, fill=class)) + geom_histogram(alpha=0.2,position="identity")
print(plt)

# write data
write.table(measLowD,"measurementPoint.csv")
