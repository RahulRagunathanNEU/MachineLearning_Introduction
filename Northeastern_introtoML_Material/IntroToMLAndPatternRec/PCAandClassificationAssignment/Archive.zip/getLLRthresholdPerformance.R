# this script accepts 2 score sets from PCA,
# assume they are independent Gaussian,
# computes llr for first and for second score
# considers performance with first and both scores

# laod data
measLowD <- read.table("measurementPoint.csv", header=TRUE)
data1 <- measLowD[measLowD$class==1,]
data2 <- measLowD[measLowD$class==2,]
# get class parameters for Gaussians
m1first <-mean(data1$firstScore)
var1first <-var(data1$firstScore)
m2first <-mean(data2$firstScore)
var2first <-var(data2$firstScore)
m1second <-mean(data1$secondScore)
var1second <-var(data1$secondScore)
m2second <-mean(data2$secondScore)
var2second <-var(data2$secondScore)

# compute llrs on common grid
gridSpacing <- 0.05
ordinate <- seq(from=-3, to=10, by=gridSpacing)
llrFirst <- log(dnorm(mean=m2first, sd=sqrt(var2first),x=ordinate))-log(dnorm(mean=m1first, sd=sqrt(var1first),x=ordinate))
llrSecond <- log(dnorm(mean=m2second, sd=sqrt(var2second),x=ordinate))-log(dnorm(mean=m1second, sd=sqrt(var1second),x=ordinate))


#priors
p1=.35
p2=1-p1
#costs
dc1 <- 1 #cost of saying 1 when wrong
dc2 <- 20 #cost of saying 2 when wrong
# false alarm rate
falseAlarm <- 1/10000

# compute log-thresholds for test with first score only
logThBayes <- log(p1*dc2/(p2*dc1))
logThMinPerr <- log(p1/p2)


# compute decision regions and risk using Riemann sums
say2Bayes <- ordinate[which(llrFirst >= logThBayes)]
Psay2BayesGiven1 <- sum(dnorm(x=say2Bayes,mean=m1first, sd=sqrt(var1first)))*gridSpacing
Psay2BayesGiven2 <- sum(dnorm(x=say2Bayes,mean=m2first, sd=sqrt(var2first)))*gridSpacing
minRisk <- dc2* Psay2BayesGiven1 + dc1 * (1-Psay2BayesGiven2)


# compute decision regions and minPerr using Riemann sums
say2minPerr <- ordinate[which(llrFirst >= logThMinPerr)]
Psay2minPerrGiven1 <- sum(dnorm(x=say2minPerr,mean=m1first, sd=sqrt(var1first)))*gridSpacing
Psay2minPerrGiven2 <- sum(dnorm(x=say2minPerr,mean=m2first, sd=sqrt(var2first)))*gridSpacing
minPerr <-  Psay2minPerrGiven1 + (1-Psay2minPerrGiven2)

# NP threshold is found by: choose llr threshold, evaluate P{false alarm} over threshold grid
# choose NP threshold as that for which P{false alarm} matches constraint
tmpThresh <- sort(llrFirst)
tmpPFA <- tmpThresh*0+1
for (idx in seq(1,length(tmpThresh))) {
say2NP <- ordinate[which(llrFirst >= tmpThresh[idx])]
tmpPFA[idx] <- sum(dnorm(x=say2NP, mean=m1first, sd=sqrt(var1first)))*gridSpacing
}
NPidx <- which.min(abs(tmpPFA-falseAlarm))
logThNP <-tmpThresh[NPidx]
myFalseAlarm <- tmpPFA[NPidx]
say2NP <- ordinate[which(llrFirst >= logThNP)]
myPower <- sum(dnorm(say2NP,mean=m2first,sd=sqrt(var2first)))*gridSpacing

# plot llrFirst and llrSecond
# also, plot thresholds on decision region for class 2
plt <- ggplot() + geom_line(aes(alpha=0.2,linewidth=5,x=ordinate, y=llrFirst, group=1, colour="llrFirstScore")) +
  geom_line(aes(alpha=0.2,linewidth=5,x=ordinate, y=llrSecond, group=2, colour="llrSecondScore")) +
  geom_point(aes(alpha=0.2,x=say2Bayes, y=say2Bayes*0+logThBayes, group=3, colour="say2Bayes")) +
  geom_point(aes(alpha=0.2,x=say2minPerr, y=say2minPerr*0+logThMinPerr, group=4, colour="say2minPerr")) +
  geom_point(aes(alpha=0.2,x=say2NP, y=say2NP*0+logThNP, group=5, colour="say2NP"))
plot(plt)
