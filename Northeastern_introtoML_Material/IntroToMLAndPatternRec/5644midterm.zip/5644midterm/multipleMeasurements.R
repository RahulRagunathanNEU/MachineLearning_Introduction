# this script considers more than 1, iid measurement
# and performs binary classification
# M measurements
M <-10
# we assume CLT applies under each class for this M
# and the log likelihood ratio is Gaussian under each class
# let's inspect this by histograms
trials <- 500
llr0Trials <- seq(1,trials)
llr1Trials <- llr0Trials
for (idxT in seq(1,trials)) {
  hist0Sample <- rbeta(M,a0,b0)
  hist1Sample <- rbeta(M,a1,b1)
  llr0Trials[idxT] <- sum(log(dbeta(hist0Sample,a1,b1)) - log(dbeta(hist0Sample,a0,b0)))
  llr1Trials[idxT] <- sum(log(dbeta(hist1Sample,a1,b1)) - log(dbeta(hist1Sample,a0,b0)))
}
xlabel <- paste("llr, M=",M)
plt <- ggplot() +
  geom_histogram(aes(x=llr0Trials,fill = "llr, C0",  alpha = 0.2), binwidth=.1) +
  geom_histogram(aes(x=llr1Trials,fill = "llr, C1", alpha = 0.2), binwidth=.1) +
  xlab(xlabel)
print(plt)

# using CLT, we estimate the exceedance probability of llr>t for
# each class
# find the means and variances of 1-sample llr for all classes
# we use the training data to do this
m0 <- mean(log(dbeta(data0,esta1,estb1))-log(dbeta(data0,esta0,estb0)))
var0 <- var(log(dbeta(data0,esta1,estb1))-log(dbeta(data0,esta0,estb0)))
m1 <- mean(log(dbeta(data1,esta1,estb1))-log(dbeta(data1,esta0,estb0)))
var1 <- var(log(dbeta(data1,esta1,estb1))-log(dbeta(data1,esta0,estb0)))
# find the class means and variances of the M-sample llr
mllr0 <- M*m0
varllr0 <- M*var0
mllr1 <- M*m1
varllr1 <- M*var1

# compute the performances
minRisk <- p0*dc1*(1-pnorm(log(Bt),mllr0,sqrt(varllr0))) + p1*dc0*pnorm(log(Bt),mllr1,sqrt(varllr1))
minPerr <- p0*(1-pnorm(log(minPt),mllr0,sqrt(varllr0))) + p1*pnorm(log(minPt),mllr1,sqrt(varllr1))
NP_threshold <- qnorm(alpha,mllr0,sqrt(varllr0),lower.tail=FALSE)
Power <- pnorm(NP_threshold, mllr1,sqrt(varllr1),lower.tail=FALSE)
FalseAlarm <- pnorm(NP_threshold, mllr0,sqrt(varllr0),lower.tail=FALSE)

#compute Bayes risk for all priors
mmp0 <- seq(from=0.01, to=0.99, by=.01)
mmBt <- mmp0*dc1/((1-mmp0)*dc0)
allBayesRisks <- mmp0*dc1*pnorm(mmBt,mllr0,sqrt(varllr0),lower.tail=FALSE) + (1-mmp0)*dc0*pnorm(mmBt,mllr1,sqrt(varllr1),lower.tail=TRUE)
# find worst case Bayes risk
worstCase <- which.max(allBayesRisks)
minmaxBayesThreshold <- mmBt[worstCase]
minmaxBayesRisk <- allBayesRisks[worstCase]