library(ggplot2)
# this script generates 1D training data for 
# two classes
#

# samples per class
npts <-300
#histogram breaks
breakGap <- 0.005
mybreaks <- seq(from=0,to=1,by=breakGap)
# create measurement range ignoring measurements 0  and 1 (can't happen here)
measurement <- mybreaks[mybreaks>0&mybreaks<1]

# class 0 is beta
a0 <- 2
b0 <- 2
data0 <- rbeta(npts,a0,b0)
# class 1 is beta
a1 <-1
b1 <-1
data1 <- rbeta(npts,a1,b1)

td <- data.frame( C=factor(rep(c("C0","C1"),each=npts)), training=c(data0, data1))
# Basic histogram
plt <- ggplot(td, aes(x=training, fill=C, alpha=0.2)) + geom_histogram(binwidth=.01) 
print(plt)

