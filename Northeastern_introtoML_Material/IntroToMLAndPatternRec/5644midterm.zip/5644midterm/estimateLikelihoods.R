# estimates parameters of beta dist
# using method of moments
m0 <- mean(td$training[td$C=="C0"])
v0 <- var(td$training[td$C=="C0"])

m1 <-mean(td$training[td$C=="C1"])
v1<- var(td$training[td$C=="C1"])

# method of moment estimators
esta0 <- m0*((m0*(1-m0)/v0)-1)
estb0 <- (1-m0)*((m0*(1-m0)/v0)-1)
esta1 <- m1*((m1*(1-m1)/v1)-1)
estb1 <- (1-m1)*((m1*(1-m1)/v1)-1)

#likelihood functions, evaluated along h-axis
l0<-dbeta(measurement,esta0,estb0)
l1<-dbeta(measurement,esta1,estb1)
#likelihood ratio, evaluated along h-axis
lr <- l1/l0

plt <- ggplot() + geom_line(aes(x=measurement, y=log(l0), linewidth=5, group=1, colour="log(l0)")) + 
 geom_line(aes(x=measurement, y=log(l1), linewidth=5, group=2, colour="log(l1)")) +
 geom_line(aes(x=measurement, y=log(lr), linewidth=5, group=3, colour="log(l1/l0)")) +
  xlab('measurement') + ylab('log likelihood functions')
print(plt)

