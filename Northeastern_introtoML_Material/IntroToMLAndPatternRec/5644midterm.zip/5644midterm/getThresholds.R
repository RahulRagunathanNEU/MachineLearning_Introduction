# set thresholds and give performance for Bayes', min Perr, and Neyman-Pearson
#priors
p0 <- 0.55
p1 <- 1-p0

#for each value of lr, find the indices of measurement at which lr is bigger 
threshold <- sort(lr, decreasing=TRUE)
Pexc0 <- threshold
Pexc1 <- threshold
indx <- 0
for (t in threshold) {
  indx <- indx+1
  Pexc0[indx] <- breakGap * sum(l0[which(lr>=t)]) # Riemann sum
  Pexc1[indx] <- breakGap * sum(l1[which(lr>=t)]) # Riemann sum
}

#Bayes costs
dc0 <- 1 #cost of wrongly saying 0
dc1 <- 2

#Bayes threshold (minimum average cost)
Bt <- p0*dc1/(p1*dc0)

# Bayes performance, and decision region for C1
idx <- which.min(abs(Bt-threshold))
minRisk <- p0*dc1*Pexc0[idx] + p1*dc0*(1-Pexc1[idx])
BayesRegion1 <- measurement[which(lr>=Bt)]

# minimum probability of error threshold
minPt <- p0/p1

#minimum probability of error and decision region for C1
idx <- which.min(abs(minPt-threshold))
minPerr <-  p0*Pexc0[idx] + p1*(1-Pexc1[idx])
PminRegion1 <- measurement[which(lr>=minPt)]

# Neyman-Pearson Threshold at level alpha
alpha <- 1/100 # false-alarm probability
idx <- which.min(abs(alpha-Pexc0))
NP_threshold <- threshold[idx]
NPRegion1 <- measurement[which(lr>=NP_threshold)]
Power <- Pexc1[idx]
FalseAlarm <- Pexc0[idx]

# we plot the llr and the decision regions for C1.  The legend describes the different tests.

plt <-ggplot() + geom_line(aes(x=measurement, y=log(lr), linewidth=10, group=1, colour="log(lr)")) +
  geom_point(aes(x=BayesRegion1, y=log(Bt)*rep(1,length(BayesRegion1)), group=2, colour="Bayes")) +
  geom_point(aes(x=PminRegion1, y=log(minPt)*rep(1,length(PminRegion1)), group=3, colour="minPerr")) +
  geom_point(aes(x=NPRegion1, y=log(NP_threshold)*rep(1,length(NPRegion1)), group=4, colour="NP")) 
print(plt)
